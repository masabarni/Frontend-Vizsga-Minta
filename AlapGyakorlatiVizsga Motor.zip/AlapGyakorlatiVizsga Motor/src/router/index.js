import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import ItemsView from '../views/ItemsView.vue'
import ItemDetailsView from '../views/ItemDetailsView.vue' 

export default createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', name: 'home', component: HomeView },
    { path: '/motors', name: 'items', component: ItemsView },
    {
      path: '/motors/:id', 
      component: ItemDetailsView,
    }
  ]
})
